require("dotenv").config();

const configurations = {
  ConnectionStrings: {
    MongoDB: "mongodb+srv://200555714:8o7WvGu3Ivn06nBe@cluster2.xncrp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster2",
  },
  Authentication: {
    Google: {
      ClientId: "263162135824-chr8e88qe86bortcdoj6vlje5fgpm2be.apps.googleusercontent.com",
      ClientSecret: "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",
      CallbackUrl: "http://localhost:3000/auth/google/callback"
    },
  }  
};
module.exports = configurations;
